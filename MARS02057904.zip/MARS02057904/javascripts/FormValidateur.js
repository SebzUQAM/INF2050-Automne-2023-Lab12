function FormValidateur(){
    this.ClassCache = "cache";
    this.champs;
    this.elements = new Object();
    this.montantReclames = [];

    this.creerElements = function(elements){
        for(let i=0;i<elements.length;i++){
            let element = new Element();
            element.affiche = i===0;
            element.index = i;
            element.element = document.getElementById(elements[i]).parentElement;
            this.elements[elements[i]] = element;
        }
    }

    this.cacherElementsSuivant = function(elements = [], index = 1){
        this.champs = elements;
        this.elements[elements[index]].affiche = false;
        this.cacherElements();
    }

    this.verifierRadio = function(radioName, champSuivant, condition = null){
        let radios = document.getElementsByName(radioName);
        let elementSuivant = document.getElementById(champSuivant).parentElement;

        
        for(i = 0; i < radios.length; i++){
            radios[i].addEventListener("change", () => {
                let value = null;
                for(let btn of radios){
                    if(btn.checked){
                        value = btn.value;
                        break;
                    }
                }
                if(value != null && condition == null || condition.includes(value)){
                    if(this.elements[champSuivant] == null){
                        elementSuivant.classList.remove(this.ClassCache);
                    }else{
                        this.elements[champSuivant].affiche = true;
                        this.cacherElements();
                    }
                }else{
                    if(this.elements[champSuivant] == null){
                        elementSuivant.classList.add(this.ClassCache);
                    }else{
                        this.elements[champSuivant].affiche = false;
                        this.cacherElements();
                    }
                }
            });
        }
    }

    this.verifierDateNaissance = function(inputId, champSuivant, placeholder){
        let elementSuivant = document.getElementById(champSuivant).parentElement;
        placeholder = document.getElementById(placeholder);
        let input = document.getElementById(inputId);
        input.addEventListener("input", (e) => {
            if(e.target.value == ""){
                placeholder.classList.add(this.ClassCache);
            }else{
                placeholder.classList.remove(this.ClassCache);
            }

            let split = e.target.value.split("/");
            if(split.length == 3){
                let date = new Date(split[2]+"/"+split[1]+"/"+split[0]);
                if(
                    date != "Invalid Date" 
                    && date.getDate() == split[0] 
                    && date.getMonth()+1 == split[1]
                    && date.getFullYear() == split[2]
                    && date.getFullYear() > 1900
                    && date < Date.now()
                    ){
                        this.elements[champSuivant].affiche = true;
                        this.cacherElements();
                }else{
                    this.elements[champSuivant].affiche = false;
                    this.cacherElements();
                }
            }else{
                this.elements[champSuivant].affiche = false;
                this.cacherElements();
            }
        });
    }

    this.verifierArgent = function(inputID, champSuivant){
        let input = document.getElementById(inputID);

        input.addEventListener("input", (e) => {
            let value = e.target.value.trim();
            if(value.charAt(value.length-1) === "$"){
                value = value.slice(0, -1);
            }

            value = value.replace(",", ".");
            let apresVirgule = value.split(".")[1];
            if(
                parseFloat(value) == value 
                && value.charAt(0) !== "-"
                && (apresVirgule === undefined 
                || (apresVirgule.length <=2 && apresVirgule.length !== 0)))
                {
                    this.elements[champSuivant].affiche = true;
                    this.cacherElements();
            }else{
                this.elements[champSuivant].affiche = false;
                this.cacherElements();
            }
        });
    }

    this.verifierAnnee = function(inputID, champSuivant){
        let input = document.getElementById(inputID);

        input.addEventListener("input", (e) => {
            e.target.value = e.target.value.trim();
            let value = parseInt(e.target.value.trim());

            if(value == e.target.value && value > 1900 && new Date().getFullYear()+1 >= value){
                this.elements[champSuivant].affiche = true;
                this.cacherElements();
            }else{
                this.elements[champSuivant].affiche = false;
                this.cacherElements();
            }
        });
    }

    this.verifierKM = function(inputID, champSuivant){
        let input = document.getElementById(inputID);

        input.addEventListener("input", (e) => {
            let value = e.target.value.trim();
        
            if(value.substring(value.length-2).toLowerCase() === "km"){
                value = value.slice(0, -2);
                value = value.trim();
            }

            if(value == parseInt(value)){
                this.elements[champSuivant].affiche = true;
                this.cacherElements();
            }else{
                this.elements[champSuivant].affiche = false;
                this.cacherElements();
            }
        });
    };

    this.verificationReclamation = function(inputID, champSuivant){
        champSuivant = document.getElementById(champSuivant).parentElement;
        let input = document.getElementById(inputID);
        let champs = [];

        input.addEventListener("input", (e) => {
            let value = e.target.value.trim();

            if(value == parseInt(value)){
                let lastElement = champSuivant;
                let currentElement;
                let inputText;
                for(let i=0; i<value; i++){
                    currentElement = champSuivant.cloneNode(true);
                    lastElement.after(currentElement);
                    currentElement.classList.remove(this.ClassCache);
                    currentElement.innerHTML = currentElement.innerHTML.replace("{{nb}}", i+1);
                    inputText = currentElement.getElementsByTagName("input")[0];
                    inputText.id = inputText.id+(i+1);
                    inputText.setAttribute( "name", inputText.getAttribute("name")+(i+1) );
                    champs.push(currentElement);
                    lastElement = currentElement;
                    this.montantReclames.push(currentElement);
                }
            }else{
                for(let i=0; i<champs.length;i++){
                    champs[i].remove();
                }
                champs = [];
            }
        });
    };

    this.cacherElements = function(champSuivant, elementSuivant){
        if(!champSuivant || this.champs.includes(champSuivant)){
            if(champSuivant){
                this.elements[champSuivant].affiche = false;
            }
            let afficher = true;
            for(let i=0; i<this.champs.length; i++){
                let element = this.elements[this.champs[i]];
                if(afficher && element.affiche){
                    element.element.classList.remove(this.ClassCache);
                    element.afficherEvent(this.montantReclames, this.ClassCache);
                }else{
                    afficher = false;
                    element.cacherEvent(this.montantReclames, this.ClassCache);
                    element.element.classList.add(this.ClassCache);
                }
            }
            let index = this.champs.indexOf(champSuivant);
        }else{
            elementSuivant.classList.add(this.ClassCache);
        }
    }

    this.cacherMontantReclames = function(montantReclames, classCache){
        for(let i=0; i<montantReclames.length; i++){
            montantReclames[i].classList.add(classCache);
        }
    }

    this.afficherMontantReclames = function(montantReclames, classCache){
        for(let i=0; i<montantReclames.length; i++){
            console.log(montantReclames[i]);
            montantReclames[i].classList.remove(classCache);
        }
    }

    function Element(){
        this.affiche = true;
        this.index;
        this.element;
        this.cacherEvent = function(){};
        this.afficherEvent = function(){};
    }
}